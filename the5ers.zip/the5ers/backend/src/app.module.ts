import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { StocksService } from './stocks/stocks.service';
import { StockModule } from './stocks/stocks.module';
import { MongooseModule } from '@nestjs/mongoose';

@Module({
  imports: [
    MongooseModule.forRoot('mongodb+srv://atarapick:K3w4p1dTkHGkmttv@stocks.d75cn.mongodb.net/'),  
  StockModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
