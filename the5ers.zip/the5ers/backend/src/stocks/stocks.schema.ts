import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema()
export class Stock extends Document {
  @Prop({ required: true })
  symbol: string;

  @Prop({ required: true })
  name: string;

  @Prop()
  price: number;

  @Prop()
  stockExchange: string;
}

export const StockSchema = SchemaFactory.createForClass(Stock);
