import { Controller, Get, Post, Delete, Param, Body } from '@nestjs/common';
import { StocksService } from './stocks.service';

@Controller('/api/stocks')
export class StocksController {
  constructor(private readonly stocksService: StocksService) {}

  @Get()
  async getAllStocks() {
    return this.stocksService.findAll();
  }

  @Post()
  async addStock(@Body() stockData) {
    return this.stocksService.create(stockData);
  }

  @Delete(':id')
  async deleteStock(@Param('id') id: string) {
    return this.stocksService.delete(id);
  }
}
