import { Module } from '@nestjs/common';
import { StocksController } from "./stocks.controller";
import { StocksService } from "./stocks.service";
import { Stock, StockSchema } from './stocks.schema';
import { MongooseModule } from '@nestjs/mongoose';

@Module({
    imports: [
        MongooseModule.forFeature(
            [
              { name: Stock.name, schema: StockSchema },
            ])
    ],

    controllers: [StocksController],
    providers: [StocksService],
    exports: [StocksService]
  })
  export class StockModule {}