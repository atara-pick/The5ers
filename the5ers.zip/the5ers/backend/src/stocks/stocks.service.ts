import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Stock } from './stocks.schema';

@Injectable()
export class StocksService {
  constructor(@InjectModel(Stock.name) private stockModel: Model<Stock>) {}

  async findAll(): Promise<Stock[]> {
    return this.stockModel.find().exec();
  }

  async create(stockData: Partial<Stock>): Promise<Stock> {
    const newStock = new this.stockModel(stockData);
    return newStock.save();
  }

  async delete(stockId: string): Promise<Stock | null> {
    return this.stockModel.findByIdAndDelete(stockId).exec();
  }

}
