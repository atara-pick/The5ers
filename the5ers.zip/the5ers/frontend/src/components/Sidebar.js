import React from 'react';
import { Layout, Menu } from 'antd';
import { Link } from 'react-router-dom';

const { Sider } = Layout;

const Sidebar = () => {
  const menuItems = [
    {
      key: '1',
      label: <Link to="/">Your Stocks</Link>,
    },
    {
      key: '2',
      label: 'Sidebar Filler',
    },
    {
      key: '3',
      label: 'Sidebar Filler',
    },
    {
      key: '4',
      label: <Link to="/logout">Log Out</Link>,
      style: { position: 'absolute', bottom: 0 },
    },
  ];

  return (
    <Sider width={200} style={{ background: '#f0f0f0' }}>
      <Menu
        mode="inline"
        defaultSelectedKeys={['1']}
        style={{ height: '100%' }}
        items={menuItems}
      />
    </Sider>
  );
};

export default Sidebar;
