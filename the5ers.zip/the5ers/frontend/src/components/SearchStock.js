import React, { useState } from 'react';
import { Button, Input } from 'antd';
import axios from 'axios';
import { stockStore } from '../stores/StockStore';

const SearchStock = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResult, setSearchResult] = useState(null);

  const handleSearch = async () => {
    const API_KEY = process.env.REACT_APP_API_KEY;
    const BASE_URL = 'https://financialmodelingprep.com/api/v3/search-name';

    try {
      const response = await axios.get(`${BASE_URL}?query=${searchTerm}&limit=10&exchange=NASDAQ&apikey=${API_KEY}`);
      setSearchResult(response.data[0]);
    } catch (error) {
      console.error("Error fetching stock data:", error);
    }
  };

  const handleAddFromSearch = async () => {
    if (searchResult) {
      const { symbol, name, stockExchange} = searchResult;
      await stockStore.addStock({ symbol, name, stockExchange });
      setSearchResult(null);
      setSearchTerm('')
    }
  };

  return (
    <div style={{ marginBottom: '20px' }}>
      <Input
        placeholder="Search stocks"
        style={{ width: 200 }}
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        onPressEnter={handleSearch}
      />
      <Button type="primary" onClick={handleSearch} style={{ marginLeft: '10px' }}>Search</Button>

      {searchResult && (
        <div style={{ marginTop: '20px', border: '1px solid #d9d9d9', padding: '10px', borderRadius: '4px' }}>
          <h3>Search Result:</h3>
          <p>Symbol: {searchResult.symbol}</p>
          <p>Name: {searchResult.name}</p>
          <p>Exchange: {searchResult.stockExchange}</p>
          <Button type="primary" onClick={handleAddFromSearch}>Add Stock</Button>
        </div>
      )}
    </div>
  );
};

export default SearchStock;
