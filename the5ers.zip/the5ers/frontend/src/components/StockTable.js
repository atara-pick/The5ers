import React from 'react';
import { observer } from 'mobx-react-lite';
import { Table, Button } from 'antd';
import { useNavigate } from 'react-router-dom';
import { stockStore } from '../stores/StockStore';

const StockTable = observer(() => {
  const navigate = useNavigate();

  return (
    <Table
      dataSource={stockStore.stocks}
      columns={[
        { title: 'Symbol', dataIndex: 'symbol', key: 'symbol' },
        { title: 'Name', dataIndex: 'name', key: 'name' },
        { title: 'Exchange', dataIndex: 'stockExchange', key: 'stockExchange' },
        {
          title: 'Action',
          key: 'action',
          render: (_, record) => (
            <Button
            onClick={(e) => {
              e.stopPropagation();
              stockStore.deleteStock(record._id);
            }}
          >
            Delete
          </Button>
          ),
        },
      ]}
        rowKey="_id"
      onRow={(record) => ({
        onClick: () => {
          navigate(`/stocks/${record.symbol}`);
        },
      })}
    />
  );
});

export default StockTable;
