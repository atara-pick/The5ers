
import React, { useEffect } from 'react';
import { observer } from 'mobx-react-lite';
import SearchStock from '../components/SearchStock';
import StockTable from '../components/StockTable';
import { stockStore } from '../stores/StockStore';

const Portfolio = observer(() => {
  useEffect(() => {
    stockStore.fetchStocks();
  }, []);

  return (
    <div style={{ padding: '20px' }}>
      <h2>Hey, your stock portfolio</h2>
      <SearchStock />
      <StockTable />
    </div>
  );
});

export default Portfolio;

