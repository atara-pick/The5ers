import React, { useEffect, useState } from 'react';
import { observer } from 'mobx-react-lite';
import { useParams } from 'react-router-dom';
import { stockStore } from '../stores/StockStore';

const StockDetails = observer(() => {
  const { symbol } = useParams();
  const [stock, setStock] = useState(null); 

  useEffect(() => {
    const fetchData = async () => {
      const fetchedStock = await stockStore.fetchStockData(symbol); 
      setStock(fetchedStock);
    };

    fetchData();
  }, [symbol]);

  if (!stock) {
    return <div>Loading...</div>;
  }

  return (
    <div style={{ padding: '20px' }}>
      <h2>{stock.name} Details</h2>
      <p>Symbol: {stock.symbol}</p>
      <p>Latest Quote: {stock.price}</p>
      <p>Today's Change: {stock.change}%</p>
    </div>
  );
});

export default StockDetails;
