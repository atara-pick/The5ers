import React from 'react';
import { BrowserRouter as Router, Route, Routes  } from 'react-router-dom';
import { Layout } from 'antd';
import Sidebar from './components/Sidebar';
import Portfolio from './pages/Portfolio';
import StockDetails from './pages/StockDetail';

const { Content } = Layout;

const App = () => (
  <Router>
  <Layout style={{ minHeight: '100vh' }}>
    <Sidebar />
    <Layout>
      <Content style={{ padding: '20px' }}>
        <Routes>
          <Route path="/" element={<Portfolio />} />
          <Route path="/stocks/:symbol" element={<StockDetails />} />
        </Routes>
      </Content>
    </Layout>
  </Layout>
</Router>
);

export default App;
