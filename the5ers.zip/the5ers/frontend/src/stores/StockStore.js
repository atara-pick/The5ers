import { makeAutoObservable, action , runInAction} from 'mobx';
import axios from 'axios';

class StockStore {
  stocks = [];

  constructor() {
    makeAutoObservable(this, {
      addStock: action,
      fetchStocks: action,
      fetchAllStocks: action
    });
  }
  async fetchStocks() {
    try {
      const response = await axios.get('/api/stocks');
      runInAction(() => {
        this.stocks = response.data;
      });
      
    } catch (error) {
      console.error("Error fetching stocks:", error);
    }
  }


  async fetchStockData(stockSymbol) {
    try {
      const apiKey = process.env.REACT_APP_API_KEY;
      const response = await axios.get(`https://financialmodelingprep.com/api/v3/quote/${stockSymbol}?apikey=${apiKey}`);
      return response.data[0]; 
    } catch (error) {
      console.error(`Error fetching stock data for ${stockSymbol}:`, error);
    }
  }

  async addStock(stock) {
    try {
      const response = await axios.post('/api/stocks', stock, {
        headers: {
          'Content-Type': 'application/json'
        }
      }); 
      runInAction(() => {
        this.stocks.push(response.data);
        this.stocks = [...this.stocks];
      });

    } catch (error) {
      console.error("Error adding stock:", error);
    }
  }

  async deleteStock(id) {
    try {
      await axios.delete(`/api/stocks/${id}`);
      this.stocks = this.stocks.filter(stock => stock._id !== id);
    } catch (error) {
      console.error("Error deleting stock:", error);
    }
  }
}

export const stockStore = new StockStore();
